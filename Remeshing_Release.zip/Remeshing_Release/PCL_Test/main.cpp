/*********************************************************************************

                     Main for Isotropic Remeshing

                        Updating in 2025/05/09

                           By Dr. Chenlei Lv

            The functions includes:
            1. Isotropic Remeshing (intput a mesh and output an isotropic one)

*********************************************************************************/

#pragma once

#include <stdio.h>
#include <stdlib.h>
#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include "FileProcess/CBrowseDir.h"
#include "FileProcess/CStatDir.hpp"
#include "PcLoad.hpp"
#include "Mesh_opt.hpp"
#include "Mesh_check.hpp"

using namespace std;

int main(){

    string FatherPath = "data//in";
    string StorePath = "..//out//";
    string fileStyle = "*.obj";
    char filePath[256];
    strcpy_s(filePath, FatherPath.c_str());
    CStatDir statdir;

    if (!statdir.SetInitDir(filePath))
    {
        cout << "error! file path wrong!" << endl;
    }

    statdir.BeginBrowse(fileStyle.c_str());
    printf("OutPut:%d\nOutPutSecond:%d\n", statdir.GetFileCount(), statdir.GetSubdirCount());
    printf("CountNumber:%d\n", statdir.lifp.size());

    vector<string> fileNameList = statdir.lifp;

    int iter = 10;
    float timeSum = 0;
    for (int i = 0; i < fileNameList.size(); i++) {

        string sourcePath = fileNameList[i];
        cout << sourcePath << endl;
        int find1 = sourcePath.find_last_of("\\");
        int find2 = sourcePath.find_last_of(".obj");
        string name_i = sourcePath.substr(find1 + 1, find2 - find1 - 4);
        string outputPath = StorePath + name_i + ".obj";

        char* sin = (char*)sourcePath.c_str();
        char* sout = (char*)outputPath.c_str();

        vector<Point3f> pointNew;
        vector<vector<int>> faceNew;        
        
        Load_Resampling lr;
        lr.Load_Resampling_init(sourcePath);//��ȡ��������
        vector<Point3f> point = lr.pointOriginal;//����Ķ���
        vector<vector<int>> face = lr.faceOriginal;//�����������Ƭ

        clock_t t1 = clock();

        MeshOptimization mo;//Isotropic Remeshing��
        mo.MeshOptimization_init(point, face, 1);//��ʼ��
        mo.MeshOptimization_Start(iter);//��ʼremshing������Ϊ��������
        faceNew = mo.MeshOptimization_GetFace();
        pointNew = mo.MeshOptimization_GetPoint();
        //regulaL = mo.MeshOptimization_Get_RegularL();

        clock_t t2 = clock();
        float timeRecord_i = (t2 - t1) / 1000.0;
        timeSum = timeSum + timeRecord_i;

        
        lr.Save_Obj(pointNew, faceNew, outputPath);
    
    }

    timeSum = timeSum / fileNameList.size();
    cout << "Our Remeshing Avg time cost:" << timeSum << endl;
    

}


