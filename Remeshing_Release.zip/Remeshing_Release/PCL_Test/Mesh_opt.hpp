/*********************************************************************************

					      Isotropic Remeshing

						 Updating in 2025/04/25

						   By Dr. Chenlei Lv

			The functions includes:
			1. Implement remeshing for a raw triangular mesh

*********************************************************************************/

#pragma once
#include "kdTree.hpp"
using namespace std;

class MeshOptimization {

private:

	KDTreeSearching kd;	
	vector<Point3f> point;	
	vector<Point3f> normalVector;
	vector<Point3f> pointOriginal;
	vector<Point3f> normalVectorGlobal;

	vector<vector<int>> face;//from 0
	vector<vector<int>> faceNew;//from 0
	vector<vector<int>> edge;
	vector<vector<int>> n_1ring;//store 1-ring points
	float l_global;
	float l_global_l;
	float l_global_s;
	int K_Global = 8;
	int iter_MLS = 10;

public:

	void MeshOptimization_init(vector<Point3f> point_input, vector<vector<int>> face_input) {

		pointOriginal = point_input;
		point = point_input;
		face = face_input;
		MeshOptimization_EdgeInit();//��������Ƭ�л�ȡ�ٱ߽ṹ��������remeshingʱ���ھ����˵���������
		MeshOptimization_Init_l();//����ƽ���߳�l��ȷ��split��collpase������
		MeshOptimization_NormalInit();//��ʼ��normal vector
		MeshOptimization_Upsampling();
		MeshOptimization_KDInit();
		//MeshOptimization_Edge2Face();
	}

	void MeshOptimization_init(vector<Point3f> point_input, vector<vector<int>> face_input, float multi) {

		pointOriginal = point_input;
		point = point_input;
		face = face_input;
		MeshOptimization_EdgeInit();//��������Ƭ�л�ȡ�ٱ߽ṹ��������remeshingʱ���ھ����˵���������
		MeshOptimization_Init_l();//����ƽ���߳�l��ȷ��split��collpase������
		MeshOptimization_NormalInit();//��ʼ��normal vector
		MeshOptimization_Upsampling();
		MeshOptimization_KDInit();

		l_global = l_global * multi;
		l_global_l = l_global_l * multi;
		l_global_s = l_global_s * multi;

		//MeshOptimization_Edge2Face();
	}

	void MeshOptimization_Start(int iter) {

		checkEdge();

		for (int i = 0; i < iter; i++) {
			cout << "Iter:" << i << endl;
			cout << "MeshOptimization_Split running..." << endl;
			MeshOptimization_Split();//ִ��Split
			cout << "MeshOptimization_Collapse running..." << endl;
			MeshOptimization_Collapse();//ִ��Collapse
			cout << "MeshOptimization_Flip running..." << endl;
			MeshOptimization_Flip();//ִ��Flip
			cout << "MeshOptimization_Tangent running..." << endl;
			MeshOptimization_Tangent();//ִ��Tangent Smoothing		
		}
		cout << "Mesh Output..." << endl;
		MeshOptimization_Edge2Face();//��edge���ݽṹ����ȡ������Ƭ����Ϣ		
		cout << "Finished!" << endl;

	}

	vector<Point3f> MeshOptimization_GetPoint() {

		return point;
	
	}

	vector<vector<int>> MeshOptimization_GetFace() {

		return faceNew;
	
	}

	float MeshOptimization_Get_RegularL() {

		return l_global;
	
	}

private:

	void MeshOptimization_KDInit() {

		kd.KDTreeSearching_init(pointOriginal);

	}

	void MeshOptimization_NormalInit() {

		for (int i = 0; i < point.size(); i++) {
			normalVectorGlobal.push_back(NormalComputation(i));
		}
	
	}

	void MeshOptimization_EdgeInit() {

		//init edge
		if (edge.size() > 0) {
			edge.clear();		
		}		

		for (int i = 0; i < point.size(); i++) {
			vector<int> edge_i;
			edge.push_back(edge_i);		
		}

		//generate neighbor infor for edge
		for (int i = 0; i < face.size(); i++) {

			int b1 = face[i][0];
			int b2 = face[i][1];
			int b3 = face[i][2];

			edge[b1].push_back(b2);
			edge[b1].push_back(b3);

			edge[b2].push_back(b3);
			edge[b2].push_back(b1);

			edge[b3].push_back(b1);
			edge[b3].push_back(b2);
		
		}

		Update1Ring();
		
	}
	
	void MeshOptimization_Init_l() {

		float sum = 0;
		int edgeIndex = 0;

		for (int i = 0; i < face.size(); i++) {

			int b1 = face[i][0];
			int b2 = face[i][1];
			int b3 = face[i][2];
			Point3f p1 = point[b1];
			Point3f p2 = point[b2];
			Point3f p3 = point[b3];		
			sum = sum + Point2length(p1, p2);
			sum = sum + Point2length(p2, p3);
			sum = sum + Point2length(p1, p3);
			edgeIndex = edgeIndex + 3;
		
		}

		l_global = sum / (float)edgeIndex;
		l_global_l = l_global*4/3;
		l_global_s = l_global*2/3;
	
	}

	void MeshOptimization_Upsampling() {

		for (int i = 0; i < face.size(); i++) {

			int b1 = face[i][0];
			int b2 = face[i][1];
			int b3 = face[i][2];

			Point3f p1 = point[b1];
			Point3f p2 = point[b2];
			Point3f p3 = point[b3];

			Point3f pn1 = normalVectorGlobal[b1];
			Point3f pn2 = normalVectorGlobal[b2];
			Point3f pn3 = normalVectorGlobal[b3];

			Point3f Middle_i = (p1 + p2 + p3)/3;
			Point3f Middle_i_N = (pn1 + pn2 + pn3)/3;			

			Point3f pm1_i = (Middle_i + p1)/2;
			Point3f pm1_i_N = (Middle_i_N + pn1) / 2;

			Point3f pm2_i = (Middle_i + p2) / 2;
			Point3f pm2_i_N = (Middle_i_N + pn2) / 2;

			Point3f pm3_i = (Middle_i + p3) / 2;
			Point3f pm3_i_N = (Middle_i_N + pn3) / 2;

			Point3f pm12_i = (pm1_i + pm2_i) / 2;
			Point3f pm12_i_N = (pm1_i_N + pm2_i_N) / 2;

			Point3f pm13_i = (pm1_i + pm3_i) / 2;
			Point3f pm13_i_N = (pm1_i_N + pm3_i_N) / 2;

			Point3f pm23_i = (pm2_i + pm3_i) / 2;
			Point3f pm23_i_N = (pm2_i_N + pm3_i_N) / 2;

			vector<Point3f> Middle_i_c = MLS_pointUpdate_Normal(Middle_i);
			vector<Point3f> pm1_i_c = MLS_pointUpdate_Normal(pm1_i);
			vector<Point3f> pm2_i_c = MLS_pointUpdate_Normal(pm2_i);
			vector<Point3f> pm3_i_c = MLS_pointUpdate_Normal(pm3_i);
			vector<Point3f> pm12_i_c = MLS_pointUpdate_Normal(pm12_i);
			vector<Point3f> pm13_i_c = MLS_pointUpdate_Normal(pm13_i);
			vector<Point3f> pm23_i_c = MLS_pointUpdate_Normal(pm23_i);

			pointOriginal.push_back(Middle_i_c[0]);
			pointOriginal.push_back(pm1_i_c[0]);
			pointOriginal.push_back(pm2_i_c[0]);
			pointOriginal.push_back(pm3_i_c[0]);
			pointOriginal.push_back(pm12_i_c[0]);
			pointOriginal.push_back(pm13_i_c[0]);
			pointOriginal.push_back(pm23_i_c[0]);

			normalVectorGlobal.push_back(Middle_i_c[1]);
			normalVectorGlobal.push_back(pm1_i_c[1]);
			normalVectorGlobal.push_back(pm2_i_c[1]);
			normalVectorGlobal.push_back(pm3_i_c[1]);
			normalVectorGlobal.push_back(pm12_i_c[1]);
			normalVectorGlobal.push_back(pm13_i_c[1]);
			normalVectorGlobal.push_back(pm23_i_c[1]);
		
		}
	
	}

	void MeshOptimization_Split() {

		//searching edge that larger than 4/3*l_global
		while (1) {

			vector<vector<int>> n_1ring_temp;

			for (int i = 0; i < n_1ring.size(); i++) {

				int b1 = i;
				Point3f p1 = point[b1];

				for (int j = 0; j < n_1ring[i].size(); j++) {
					int b2 = n_1ring[i][j];
					if (b2 < b1) {
						continue;
					}
					Point3f p2 = point[b2];
					if (Point2length(p1, p2) > l_global_l && (Split_Angle(b1,b2) > 0)) {
						vector<int> l_temp;
						l_temp.push_back(b1);
						l_temp.push_back(b2);
						n_1ring_temp.push_back(l_temp);
					}
				}

			}

			if (n_1ring_temp.size() == 0) {
				cout << endl;
				break;
			}
			else {
				cout << n_1ring_temp.size() << ", ";

			}

			//vector<Point3f> pointNew;
			//vector<vector<int>> edgeNew;
			int pIndex = point.size();
			for (int i = 0; i < n_1ring_temp.size(); i++) {

				int b1 = n_1ring_temp[i][0];
				int b2 = n_1ring_temp[i][1];

				Point3f middleP;
				middleP[0] = (point[b1][0] + point[b2][0]) / 2;
				middleP[1] = (point[b1][1] + point[b2][1]) / 2;
				middleP[2] = (point[b1][2] + point[b2][2]) / 2;

				point.push_back(middleP);

				//establishing edgeNew
				//search four neighbor points 
				vector<int> b1b2CN = CommonNeighbor(b1, b2);

				//update b1,b2
				Split_Update_EdgeP(b1, b2, pIndex);
				Split_Update_EdgeP(b2, b1, pIndex);

				//update b3,b4
				for (int j = 0; j < b1b2CN.size(); j++) {
					Split_UpdatebCommomP(b1b2CN[j], b1, b2, pIndex);
				}

				//generate new edge for new point
				vector<int> edgeNew_i = Split_GenerateNewEdge(b1, b2, pIndex);
				edge.push_back(edgeNew_i);

				//update point index;
				pIndex++;

			}

			Update1Ring();

			//checkPoint();
		
		}
		
			
	}

	void MeshOptimization_Collapse() {		

		while (1) {				

			vector<vector<int>> n_1ring_temp;
			vector<bool> point_judge(point.size(), false);				

			for (int i = 0; i < point_judge.size(); i++) {

				if (EdgeJudgePoint(i)) {

					point_judge[i] = true;
				
				};
			
			}

			for (int i = 0; i < n_1ring.size(); i++) {
				int b1 = i;
				Point3f p1 = point[b1];
				if (point_judge[b1]) {
					continue;
				}
				for (int j = 0; j < n_1ring[i].size(); j++) {
					int b2 = n_1ring[i][j];
					if (b2 < b1 || point_judge[b2] || point_judge[b1] ) {
						continue;
					}	
					//if (!Collapse_CommonEdge(b1, b2)) {
						//continue;					
					//}
					Point3f p2 = point[b2];
					if (Point2length(p1, p2) < l_global_s && (Collapse_Degree(b1, b2) > 0)) {
						point_judge[b1] = true;
						point_judge[b2] = true;						
						vector<int> l_temp;
						l_temp.push_back(b1);
						l_temp.push_back(b2);
						n_1ring_temp.push_back(l_temp);
					}
				}
			}

			if (n_1ring_temp.size() == 0) {
				cout << endl;
				break;
			}
			else {
				cout << n_1ring_temp.size() << ", ";

			}

			vector<int> pointIndex(point.size());
			for (int i = 0; i < pointIndex.size(); i++) {
				pointIndex[i] = i;
			}				

			for (int i = 0; i < n_1ring_temp.size(); i++) {				

				int b1 = n_1ring_temp[i][0];
				int b2 = n_1ring_temp[i][1];

				Point3f middleP;
				middleP[0] = (point[b1][0] + point[b2][0]) / 2;
				middleP[1] = (point[b1][1] + point[b2][1]) / 2;
				middleP[2] = (point[b1][2] + point[b2][2]) / 2;

				//��b1���ƶ���������е�
				point[b1] = middleP;

				//����b1��edge��b2�ھӵ�edge
				//edge[b1].clear();edge[b2].clear();				
				

				Collapse_Update_Edge(b1, b2);					
				
				//ɾ��b2
				pointIndex[b2] = -1;					

			}

			

			//update point index
			int count_index = 0;
			vector<Point3f> point_new;
			for (int i = 0; i < pointIndex.size(); i++) {
				if (pointIndex[i] == -1) {
					
					continue;
				}
				else {
					point_new.push_back(point[i]);
					pointIndex[i] = count_index;
					count_index++;
				}
			}

			point.clear();
			point = point_new;			
			
			vector<vector<int>> edge_new;
			for (int i = 0; i < pointIndex.size(); i++) {				
				
				if (pointIndex[i] == -1) {
					continue;
				}
				else {
					vector<int> edge_i = edge[i];
					for (int j = 0; j < edge_i.size(); j++) {
						int bn1 = edge_i[j];
						if (bn1 < 0) {
							cout << "error!" << endl;							
						}
						else if(pointIndex[bn1] < 0){
							cout << "error!" << endl;						
						}
						else {
							edge_i[j] = pointIndex[bn1];
						}
					}
					edge_new.push_back(edge_i);
					if (edge_i.size() == 0) {
						cout << "Hello";					
					}
				}
			}

			edge.clear();
			edge = edge_new;			
			Update1Ring();			
			//checkPoint();			
			
		}			

	}

	void MeshOptimization_Flip() {		

		while (1) {

			vector<vector<int>> n_1ring_temp;
			vector<bool> point_judge(point.size(), false);

			//������ҪFlip�ı�
			for (int i = 0; i < n_1ring.size(); i++) {
				int b1 = i;
				if (point_judge[b1]) {
					continue;
				}
				for (int j = 0; j < n_1ring[i].size(); j++) {
					int b2 = n_1ring[i][j];
					if (b2 < b1 || point_judge[b1] || point_judge[b2]) {
						continue;
					}
					if (Flip_Judge(b1, b2)) {
						if (Flip_Angle(b1, b2)) {
							vector<int> l_temp;
							l_temp.push_back(b1);
							l_temp.push_back(b2);
							n_1ring_temp.push_back(l_temp);
							point_judge[b1] = true;
							point_judge[b2] = true;					
						}						
					}
				}
			}

			if (n_1ring_temp.size() == 0) {
				cout << endl;
				break;			
			}
			else {
				cout << n_1ring_temp.size() << ", ";
			
			}			

			//ִ��Flip
			for (int i = 0; i < n_1ring_temp.size(); i++) {

				Flip_Edge(n_1ring_temp[i][0], n_1ring_temp[i][1]);			

			}

			Update1Ring();	

			//checkPoint();
		
		}	

	}

	void MeshOptimization_Tangent() {

		if (normalVector.size() > 0) {
			normalVector.clear();		
		}				

		for (int i = 0;i< point.size(); i++) {
			normalVector.push_back(NormalComputation(i));
		}

		vector<bool> point_judge(point.size(), false);
		for (int i = 0; i < n_1ring.size(); i++) {
			int b1 = i;
			if (point_judge[b1]) {
				continue;
			}
			for (int j = 0; j < n_1ring[i].size(); j++) {
				int b2 = n_1ring[i][j];
				if (EdgeJudge(b1, b2)) {
					point_judge[b1] = true;
					point_judge[b2] = true;
				}				
			}
		}

		vector<Point3f> point_new(point.size());
		for (int i = 0; i < point.size(); i++) {			
			//if (i == 682) {
				//cout << "Hello!";			
			//}
			if (point_judge[i]) {
				point_new[i] = point[i];
			}
			else {
				Point3f point_i = Tangent_Location(i);
				point_new[i] = point_i;	
				if (!(point_i[0] > -9999 && point_i[0] < 9999)) {
					point_new[i] = point[i];
				}
			}	
			point_new[i] = MLS_pointUpdate(point_new[i]);
		}
		
		point.clear();
		point = point_new;

	}
	
	//���뵱split�󣬲������µıߵ���̵ĳ��ȣ������split������˺̵ܶıߣ�������split��ִ�У�
	float Split_New_Edge_Length(int b1, int b2) {

		float edge_small  = 9999;
		vector<int> b1b2CN = CommonNeighbor(b1, b2);
		Point3f middleP;
		middleP[0] = (point[b1][0] + point[b2][0]) / 2;
		middleP[1] = (point[b1][1] + point[b2][1]) / 2;
		middleP[2] = (point[b1][2] + point[b2][2]) / 2;
		for (int i = 0; i < b1b2CN.size(); i++) {	

			int b1b2_i = b1b2CN[i];
			float length_temp = Point2length(middleP, point[b1b2_i]);
			if (length_temp < edge_small) {
				edge_small = length_temp;			
			}
		
		}
		return edge_small;
	
	}

	//split�۽Ǽ�飬���split������µĶ۽ǣ�������split��ִ��
	float Split_Angle(int b1, int b2) {

		vector<int> b1b2CN = CommonNeighbor(b1, b2);
		
		if (b1b2CN.size() == 2) {

			int b3 = b1b2CN[0];
			int b4 = b1b2CN[1];

			Point3f vb1b2 = point[b2] - point[b1];
			Point3f vb1b3 = point[b3] - point[b1];
			Point3f vb1b4 = point[b4] - point[b1];

			float cos1 = VectorCosAngle(vb1b2, vb1b3);
			float cos2 = VectorCosAngle(vb1b2, vb1b4);
			if (cos1 < 0 || cos2 < 0) {

				return -1;
			
			}

			Point3f vb2b1 = -vb1b2;
			Point3f vb2b3 = point[b3] - point[b2];
			Point3f vb2b4 = point[b4] - point[b2];

			float cos3 = VectorCosAngle(vb2b1, vb2b3);
			float cos4 = VectorCosAngle(vb2b1, vb2b4);
			if (cos3 < 0 || cos4 < 0) {

				return -1;

			}
		
		}

		return 1;	
	
	}

	//����Ա�b1��b2����split������µ�newP������b1��edge�ṹ
	void Split_Update_EdgeP(int b1, int b2, int newP) {

		for (int i = 0; i < edge[b1].size() / 2; i++) {
			int b1_1 = edge[b1][2 * i];
			int b1_2 = edge[b1][2 * i + 1];
			if (b1_1 == b2) {
				edge[b1][2 * i] = newP;
			}
			else if (b1_2 == b2) {
				edge[b1][2 * i + 1] = newP;
			}
		}	
	
	}

	//����Ա�b1��b2����split������µ�newP������b1��b2�����ھ�b3��edge�ṹ
	void Split_UpdatebCommomP(int b3, int b1, int b2, int newP) {

		vector<int> edge_b3;

		for (int i = 0; i < edge[b3].size() / 2; i++) {
			int b1_1 = edge[b3][2 * i];
			int b1_2 = edge[b3][2 * i + 1];
			if ((b1_1 == b1 && b1_2 == b2)|| (b1_1 == b2 && b1_2 == b1)) {
				edge_b3.push_back(b1_1);
				edge_b3.push_back(newP);
				edge_b3.push_back(newP);
				edge_b3.push_back(b1_2);
			}else {
				edge_b3.push_back(b1_1);
				edge_b3.push_back(b1_2);			
			}
		}

		edge[b3].clear();
		edge[b3] = edge_b3;

	}

	//split�������µ�newP��edge�ṹ
	vector<int> Split_GenerateNewEdge(int b1, int b2, int newP) {

		vector<int> edge_new;

		for (int i = 0; i < edge[b1].size() / 2; i++) {

			int b1_1 = edge[b1][2 * i];
			int b1_2 = edge[b1][2 * i + 1];

			if (b1_1 == newP) {
				edge_new.push_back(b1_2);
				edge_new.push_back(b1);			
			}
			else if (b1_2 == newP) {
				edge_new.push_back(b1);
				edge_new.push_back(b1_1);
			}
			else {
				continue;			
			}
		
		}

		for (int i = 0; i < edge[b2].size() / 2; i++) {

			int b2_1 = edge[b2][2 * i];
			int b2_2 = edge[b2][2 * i + 1];

			if (b2_1 == newP) {
				edge_new.push_back(b2_2);
				edge_new.push_back(b2);
			}
			else if (b2_2 == newP) {
				edge_new.push_back(b2);
				edge_new.push_back(b2_1);
			}
			else {
				continue;
			}

		}

		return edge_new;
	
	}

	//��Collapse��ʱ�����һ����Χdegree�ı仯�������degree�ķ����ǲ��õģ�������Collapse
	float Collapse_Degree(int b1, int b2) {

		vector<int> b1Neighbor = n_1ring[b1];
		vector<int> b2Neighbor = n_1ring[b2];

		int b1_degree = b1Neighbor.size();//b1�Ķ�
		int b2_degree = b2Neighbor.size();//b2�Ķ�
		int degreeJudge = 6;

		if (EdgeJudge(b1, b2)) {
			degreeJudge = 4;		
		}

		int new_degree_diff = abs((b1_degree + b2_degree - 4) - degreeJudge);
		int b1_degree_diff = abs(b1_degree - degreeJudge);
		int b2_degree_diff = abs(b2_degree - degreeJudge);

		if (b2_degree_diff > b1_degree_diff) {

			b1_degree_diff = b2_degree_diff;
		
		}

		if (new_degree_diff > b1_degree_diff) {

			return 0;
		
		}

		return 1;
	}

	//Collapse�󣬸�����ص��edge�ṹ
	void Collapse_Update_Edge(int b1, int b2) {
		
		vector<int> edge_b1 = edge[b1];
		vector<int> edge_b2 = edge[b2];
		vector<int> edge_b1_new;

		for (int i = 0; i < edge_b1.size()/2; i++) {

			int b1_1 = edge_b1[2 * i];
			int b1_2 = edge_b1[2 * i + 1];
			if (b1_1 == b2 || b1_2 == b2) {
				continue;			
			}
			else {
				edge_b1_new.push_back(b1_1);
				edge_b1_new.push_back(b1_2);			
			}
					
		}

		for (int i = 0; i < edge_b2.size() / 2; i++) {

			int b2_1 = edge_b2[2 * i];
			int b2_2 = edge_b2[2 * i + 1];
			if (b2_1 == b1 || b2_2 == b1) {
				continue;
			}
			else {
				edge_b1_new.push_back(b2_1);
				edge_b1_new.push_back(b2_2);
			}

		}

		edge[b1].clear();
		edge[b1] = edge_b1_new;

		//if (!checkEdge_i(edge_b1_new)) {

			//cout << "Hello";

		//}

		//update b2 neighbor
		vector<int> b2_neioghbor = CheckRepeat(edge[b2]);
		for (int i = 0; i < b2_neioghbor.size(); i++) {

			int b2_i = b2_neioghbor[i];			

			if (b2_i == b1) {
				continue;
			}
			vector<int> edge_i = edge[b2_i];
			vector<int> edge_i_new;
			for (int j = 0; j < edge_i.size()/2; j++) {

				int b2_i1 = edge_i[2 * j];
				int b2_i2 = edge_i[2 * j + 1];
				if ((b2_i1 == b1 && b2_i2 == b2) || (b2_i1 == b2 && b2_i2 == b1)) {
					continue;				
				}
				else if(b2_i1==b2){
					b2_i1 = b1;				
				}
				else if (b2_i2 ==b2) {
					b2_i2 = b1;
				}
				edge_i_new.push_back(b2_i1);
				edge_i_new.push_back(b2_i2);

			}
			edge[b2_i].clear();
			edge[b2_i] = edge_i_new;

			//if (!checkEdge_i(edge_i_new)) {

				//cout << "Hello";
			
			//}

		}

		edge[b2].clear();		
	
	}

	//Collaspe�����߿���
	bool Collapse_CommonEdge(int b1, int b2) {

		vector<int> b12 = CommonNeighbor(b1, b2);

		if (b12.size() == 2) {
			int b3 = b12[0];
			int b4 = b12[1];
			vector<int> b3Neighbor = n_1ring[b3];
			for (int i = 0; i < b3Neighbor.size(); i++) {
				if (b3Neighbor[i] == b4) {
					return false;				
				}			
			}		
		}

		vector<int> b1Neighbor = n_1ring[b1];
		vector<int> edge_b2 = edge[b2];
		for (int i = 0; i < edge_b2.size()/2; i++) {
			int b2_1 = edge_b2[2 * i];
			int b2_2 = edge_b2[2 * i + 1];
			if (checkVector(b2_1, b1Neighbor) && checkVector(b2_2, b1Neighbor)) {
				return false;		
			}		
		}

		return true;
	
	
	}

	//�ж�b1��b2�ı��Ƿ����Flip���������Ƿ����ص��degree�кô�
	bool Flip_Judge(int b1, int b2) {

		if (EdgeJudge(b1, b2)) {
			return false;
		}

		int before_degree = -1;
		int after_degree = -1;

		vector<int> b1Neighbor = n_1ring[b1];
		vector<int> b2Neighbor = n_1ring[b2];

		int b1_degree = b1Neighbor.size();//b1�Ķ�
		int b2_degree = b2Neighbor.size();//b2�Ķ�
		int degreeJudge = 6;		

		int b1_degree_after = abs(b1_degree - 1 - degreeJudge);
		int b2_degree_after = abs(b2_degree - 1 - degreeJudge);
		int b1_degree_before = abs(b1_degree  - degreeJudge);
		int b2_degree_before = abs(b2_degree  - degreeJudge);

		if (b1_degree_after < b2_degree_after) {
			b1_degree_after = b2_degree_after;
		}

		if (b1_degree_before < b2_degree_before) {
			b1_degree_before = b2_degree_before;
		
		}

		after_degree = b1_degree_after;
		before_degree = b1_degree_before;

		vector<int> b12 = CommonNeighbor(b1, b2);

		if (b12.size() == 2) {
			Point3f n1v = Tri_Normal(b1, b2, b12[0]);
			Point3f n2v = Tri_Normal(b1, b2, b12[1]);
			float n12 = n1v[0] * n2v[0] + n1v[1] * n2v[1] + n1v[2] * n2v[2];
			float n21 = -n1v[0] * n2v[0] - n1v[1] * n2v[1] - n1v[2] * n2v[2];
			if (n21 > n12) {
				n2v = -n2v;			
			}
			float cosValue = VectorCosAngle(n1v, n2v);		
			if (cosValue < 0.9) {
				return false;			
			}
		}
		

		int b12_degree = -1;
		for (int i = 0; i < b12.size(); i++) {		
			int b12_i_degree = n_1ring[b12[i]].size();
			int b12_i_degree_after = abs(b12_i_degree + 1 - degreeJudge);
			int b12_i_degree_before = abs(b12_i_degree - degreeJudge);
			if (b12_i_degree_after > after_degree) {
				after_degree = b12_i_degree_after;
			}	
			if (b12_i_degree_before > before_degree) {
				before_degree = b12_i_degree_before;
			}
		}

		if (after_degree < before_degree) {

			return true;
		
		}
		else {

			return false;
		
		}
	
	}

	//Flip�����ص��edge�ṹ���и���
	void Flip_Edge(int b1, int b2) {		

		vector<int> b12_N = CommonNeighbor(b1, b2);

		if (b12_N.size() != 2) {			
			cout << "Flip_Edge Common Edge Error!" << endl;		
		}

		int b3 = b12_N[0];
		int b4 = b12_N[1];

		//update edge;
		//update b1,b2
		int b1_first = -1;
		int b1_second = -1;
		vector<int> edge_b1;
		for (int i = 0; i < edge[b1].size()/2; i++) {
			int b11 = edge[b1][2 * i];
			int b12 = edge[b1][2 * i + 1];
			if (b11 == b2) {
				b1_second = b12;			
			}
			else if (b12 == b2) {
				b1_first = b11;
			}
			else {
				edge_b1.push_back(b11);
				edge_b1.push_back(b12);
			}		
		}
		if (b1_first < 0 || b1_second < 0) {			
			cout << "Flip_Edge Error!" << endl;		
		}
		edge_b1.push_back(b1_first);
		edge_b1.push_back(b1_second);
		edge[b1].clear();
		edge[b1] = edge_b1;

		int b2_first = -1;
		int b2_second = -1;
		vector<int> edge_b2;
		for (int i = 0; i < edge[b2].size() / 2; i++) {
			int b21 = edge[b2][2 * i];
			int b22 = edge[b2][2 * i + 1];
			if (b21 == b1) {
				b2_second = b22;
			}
			else if (b22 == b1) {
				b2_first = b21;
			}
			else {
				edge_b2.push_back(b21);
				edge_b2.push_back(b22);
			}
		}
		if (b2_first < 0 || b2_second < 0) {			
			cout << "Flip_Edge Error!" << endl;
		}
		edge_b2.push_back(b2_first);
		edge_b2.push_back(b2_second);
		edge[b2].clear();
		edge[b2] = edge_b2;

		//update b3,b4
		vector<int> edge_b3;
		for (int i = 0; i < edge[b3].size() / 2; i++) {
			int b31 = edge[b3][2 * i];
			int b32 = edge[b3][2 * i + 1];
			if ((b31 == b1 && b32==b2)|| (b31 == b2 && b32 == b1)) {
				edge_b3.push_back(b31);
				edge_b3.push_back(b4);
				edge_b3.push_back(b4);
				edge_b3.push_back(b32);
			}			
			else {
				edge_b3.push_back(b31);
				edge_b3.push_back(b32);
			}
		}
		edge[b3].clear();
		edge[b3] = edge_b3;

		vector<int> edge_b4;
		for (int i = 0; i < edge[b4].size() / 2; i++) {
			int b41 = edge[b4][2 * i];
			int b42 = edge[b4][2 * i + 1];
			if ((b41 == b1 && b42 == b2) || (b41 == b2 && b42 == b1)) {
				edge_b4.push_back(b41);
				edge_b4.push_back(b3);
				edge_b4.push_back(b3);
				edge_b4.push_back(b42);
			}
			else {
				edge_b4.push_back(b41);
				edge_b4.push_back(b42);
			}
		}
		edge[b4].clear();
		edge[b4] = edge_b4;
	
	}

	//�ж϶�b1��b2�ı߽���Flip����Χ�Ƿ������۽�
	bool Flip_Angle(int b1, int b2) {

		//Compute b1, b2 angle
		vector<int> b12_N = CommonNeighbor(b1, b2);
		if (b12_N.size() != 2) {
			cout << "Flip_Edge Common Edge Error!" << endl;
		}
		int b3 = b12_N[0];
		int b4 = b12_N[1];

		Point3f v31 = point[b3] - point[b1];
		Point3f v41 = point[b4] - point[b1];
		Point3f v32 = point[b3] - point[b2];
		Point3f v42 = point[b4] - point[b2];	
		float cosangle1 = VectorCosAngle(v31, v41);
		float cosangle2 = VectorCosAngle(v32, v42);

		if (cosangle1 < 0 || cosangle2 < 0) {
			return false;								
		}		

		return true;

	}

	//����һ���㾭��tangent smoothing����µ�λ��
	Point3f Tangent_Location(int b1) {

		vector<int> b1_neighbor = n_1ring[b1];
		if (b1_neighbor.size() == 0) {
			vector<int> hellot = edge[b1];
			return point[b1];		
		}
		Point3f normalb1 = normalVector[b1];
		Point3f pb1 = point[b1];
		Point3f pbNew(0,0,0);
		for (int i = 0; i < b1_neighbor.size(); i++) {
			int b1_neighbor_index = b1_neighbor[i];
			pbNew[0] = pbNew[0] + point[b1_neighbor_index][0];
			pbNew[1] = pbNew[1] + point[b1_neighbor_index][1];
			pbNew[2] = pbNew[2] + point[b1_neighbor_index][2];		
		}
		pbNew[0] = pbNew[0] / b1_neighbor.size();
		pbNew[1] = pbNew[1] / b1_neighbor.size();
		pbNew[2] = pbNew[2] / b1_neighbor.size();
		Point3f pb_m = Tangent_Map(normalb1, pb1, pbNew);

		pbNew[0] = point[b1][0] * 1 / 2 + pb_m[0] / 2;
		pbNew[1] = point[b1][1] * 1 / 2 + pb_m[1] / 2;
		pbNew[2] = point[b1][2] * 1 / 2 + pb_m[2] / 2;		

		return pbNew;	
	}

	//����һ���㵽ƽ���ͶӰ����
	Point3f Tangent_Map(Point3f nV, Point3f p, Point3f x) {//����һ����ƽ���ϵ�ͶӰ

		Point3f pxV = x - p;
		float t = (nV[0] * pxV[0] + nV[1] * pxV[1] + nV[2] * pxV[2])/(nV[0] * nV[0]+ nV[1] * nV[1] + nV[2] * nV[2]);
		Point3f tn = t * nV;
		Point3f x_map = x - tn;	
		return x_map;
	
	}

	//����һ����ķ�����
	Point3f NormalComputation(int b1) {

		vector<float> area_weight;
		vector<Point3f> normal_neighbor;
		float area_sum = 0;

		for (int i = 0; i < edge[b1].size() / 2; i++) {
			int b1_1 = edge[b1][2 * i];
			int b1_2 = edge[b1][2 * i + 1];
			float area_i = Tri_Area(b1, b1_1, b1_2);
			Point3f normal_i = Tri_Normal(b1, b1_1, b1_2);
			area_weight.push_back(area_i);
			normal_neighbor.push_back(normal_i);
			area_sum = area_sum + area_i;		
		}

		Point3f normalb1;
		for (int i = 0; i < normal_neighbor.size(); i++) {
			float weight_i = area_weight[i] / area_sum;
			normalb1[0] = weight_i * normal_neighbor[i][0];
			normalb1[1] = weight_i * normal_neighbor[i][1];
			normalb1[2] = weight_i * normal_neighbor[i][2];		
		}

		float normalLength = sqrt(normalb1[0] * normalb1[0] + normalb1[1] * normalb1[1] + normalb1[2] * normalb1[2]);
		normalb1[0] = normalb1[0] / normalLength;
		normalb1[1] = normalb1[1] / normalLength;
		normalb1[2] = normalb1[2] / normalLength;

		return normalb1;
	
	}

	//����һ�������ε����
	float Tri_Area(int b1, int b2, int b3) {//����һ��������Ƭ�����

		Point3f p1 = point[b1];
		Point3f p2 = point[b2];
		Point3f p3 = point[b3];

		//���׹�ʽ
		float a = Point2length(p1, p2);
		float b = Point2length(p2, p3);
		float c = Point2length(p3, p1);
		float p = (a + b + c) / 2;
		float S = p * (p - a) * (p - b) * (p - c);
		return S;
	
	}

	//����һ�������εķ�����
	Point3f Tri_Normal(int b1, int b2, int b3) {//����һ��������Ƭ�ķ�����

		Point3f v1 = point[b2] - point[b1];
		Point3f v2 = point[b3] - point[b2];

		Point3f normalV12;
		normalV12[0] = v1[1] * v2[2] - v1[2] * v2[1];
		normalV12[1] = v1[2] * v2[0] - v1[0] * v2[2];
		normalV12[2] = v1[0] * v2[1] - v1[1] * v2[0];

		return normalV12;

	}

	//�ж�b1��b2�ı��Ƿ�������ı߽���
	bool EdgeJudge(int b1, int b2) {//�ж�һ�����Ƿ�Ϊ�߽�

		vector<int> b1_neighbor = edge[b1];
		int count = 0;
		for (int i = 0; i < b1_neighbor.size()/2; i++) {
			int b1_1 = b1_neighbor[2 * i];
			int b1_2 = b1_neighbor[2 * i + 1];
			if (b1_1 == b2 || b1_2 == b2) {
				count++;		
			}		
		}

		if (count == 1) {
			return true;		
		}

		return false;
	
	}

	//�ж�b1�Ƿ��Ǳ߽��
	bool EdgeJudgePoint(int b1) {

		vector<int> b1_neighbor = n_1ring[b1];
		int count = 0;
		for (int i = 0; i < b1_neighbor.size(); i++) {
			int b1_1 = b1_neighbor[i];			
			if (EdgeJudge(b1, b1_1)) {
				return true;			
			}
		}
		return false;	
	
	}

	//��������������cosֵ
	float VectorCosAngle(Point3f v1, Point3f v2) {

		float v1v2_multi = v1[0] * v2[0] + v1[1] * v2[1] + v1[2] * v2[2];
	    float v1_mo = sqrt(v1[0] * v1[0] + v1[1] * v1[1] + v1[2] * v1[2]);
		float v2_mo = sqrt(v2[0] * v2[0] + v2[1] * v2[1] + v2[2] * v2[2]);
		float CosAngle = v1v2_multi / (v1_mo * v2_mo);
		return CosAngle;
	
	}

	//������������Ĺ�ͬ���ھ�
	vector<int> CommonNeighbor(int b1, int b2) {//help to check common neighbors

		vector<int> b1_neighboir = edge[b1];		
		vector<int> common_Vector;

		for (int i = 0; i < b1_neighboir.size()/2; i++) {

			int b1_1 = b1_neighboir[2 * i];
			int b1_2 = b1_neighboir[2 * i + 1];	
			if (b1_1 == b2) {
				common_Vector.push_back(b1_2);			
			}
			else if (b1_2 == b2) {
				common_Vector.push_back(b1_1);
			}
			else {
				continue;			
			}
		
		}

		vector<int> cv = CheckRepeat(common_Vector);
		return cv;
	
	}

	//������edge�ṹ�����¼���ÿ�����1������ھӵ�
	void Update1Ring() {

		if (n_1ring.size() > 0) {
			n_1ring.clear();
		}

		for (int i = 0; i < edge.size(); i++) {
			vector<int> n_1ring_i = CheckRepeat(edge[i]);
			n_1ring.push_back(n_1ring_i);
		}

	}

	//��һ��vector���ظ�����ɾ��
	vector<int> CheckRepeat(vector<int> edge_temp) {	

		vector<int> checkVector;
		for (int i = 0; i < edge_temp.size(); i++) {
			int point_i = edge_temp[i];
			bool judgeR = false;
			for (int j = 0; j < checkVector.size(); j++) {
				if (point_i == checkVector[j]) {
					judgeR = true;
					break;
				}			
			}	
			if (!judgeR) {
				checkVector.push_back(point_i);
			}
		}
		return checkVector;	
	}

	//������������ľ���
	float Point2length(Point3f p1, Point3f p2) {

		float length_Temp = (p1[0] - p2[0]) * (p1[0] - p2[0]) + (p1[1] - p2[1]) * (p1[1] - p2[1]) + (p1[2] - p2[2]) * (p1[2] - p2[2]);
		length_Temp = sqrt(length_Temp);
		return length_Temp;
	
	}

	//��edge�ṹ�У�����������Ƭ
	void MeshOptimization_Edge2Face() {

		vector<vector<int>> face_Temp;

		for (int i = 0; i < edge.size(); i++) {
			
			int b1 = i;
			vector<int> edge_i = edge[i];

			for (int j = 0; j < edge_i.size() / 2; j++) {

				int b2 = edge_i[2 * j];
				int b3 = edge_i[2 * j + 1];

				if (b2 == -1 || b3 == -1) {
					continue;				
				}
				else {

					vector<int> face_ij;
					face_ij.push_back(b1);
					face_ij.push_back(b2);
					face_ij.push_back(b3);
					MeshOptimization_Edge2Face_Check(b1, b2, b3);
					face_Temp.push_back(face_ij);
				
				}			
			
			}
		
		}

		faceNew = face_Temp;
	
	}

	//���һ����Ƭ�Ѿ�������������ô����Ƭ������������ĸ�������������ɾ��
	void MeshOptimization_Edge2Face_Check(int b1, int b2, int b3) {

		//check b2;

		for (int i = 0; i < edge[b2].size()/2; i++) {

			int b2_1 = edge[b2][2 * i];
			int b2_2 = edge[b2][2 * i + 1];
			
			if ((b2_1 == b1&&b2_2 == b3)|| (b2_1 == b3 && b2_2 == b1)) {
				edge[b2][2 * i]= -1;
				edge[b2][2 * i + 1] = -1;
			}
			else {
				continue;
			}					
		
		}

		//check b3;
		for (int i = 0; i < edge[b3].size() / 2; i++) {

			int b3_1 = edge[b3][2 * i];
			int b3_2 = edge[b3][2 * i + 1];

			if ((b3_1 == b1 && b3_2 == b2) || (b3_1 == b2 && b3_2 == b1)) {
				edge[b3][2 * i] = -1;
				edge[b3][2 * i + 1] = -1;
			}
			else {
				continue;
			}

		}
	
	
	}

	//check point
	void checkPoint() {		

		vector<int> p_index(point.size(), 0);
		int count = 0;
		for (int i = 0; i < point.size(); i++) {
			if (n_1ring[i].size() == 0) {
				if (checkPointP(i)) {
					cout << "Hello" << endl;				
				}
				p_index[i] = -1;
				cout << "Single Point error!" << endl;

				vector<int> edgetest_t = edge[1187];
				//vector<int> edgetest2_t = edge[162];
			}
			else {
				p_index[i] = count;
				count++;			
			}
		}

		//DELETE i
		vector<Point3f> point_new;
		vector<vector<int>> edge_new;
		for (int i = 0; i < p_index.size(); i++) {

			if (p_index[i] == -1) {
				continue;
			}
			else {
				vector<int> edge_i = edge[i];
				for (int j = 0; j < edge_i.size(); j++) {
					int bn1 = edge_i[j];
					if (bn1 < 0) {
						cout << "error!" << endl;
					}
					else if (p_index[bn1] < 0) {
						cout << "error!" << endl;
					}
					else {
						edge_i[j] = p_index[bn1];
					}
				}
				edge_new.push_back(edge_i);
				point_new.push_back(point[i]);
			}
		}

		point.clear();
		point = point_new;
		edge.clear();
		edge = edge_new;		

		Update1Ring();

	}

	bool checkPointP(int p1) {

		for (int j = 0; j < edge.size(); j++) {
			for (int k = 0; k < edge[j].size(); k++) {
				if (edge[j][k] == p1) {
					cout << "j:" << j<<endl;
					cout << "k:" << k << endl;
					return true;
				}
			}
		}
		return false;
	
	
	}

	bool checkEdge() {

		//����Ƿ����ظ�������

		for (int i = 0; i < edge.size(); i++) {
			for (int j = 0; j < edge[i].size() / 2; j++) {
				int b1 = edge[i][2 * j];
				int b2 = edge[i][2 * j + 1];	
				for (int k = j + 1; k < edge[i].size() / 2; k++) {
					int b1_k = edge[i][2 * k];
					int b2_k = edge[i][2 * k + 1];
					if ((b1 == b1_k && b2 == b2_k) || (b1 == b2_k && b2 == b1_k)) {

						cout << "Hello";
						return true;
					
					
					}
				
				}
			}		
		}	

		return false;
	
	}

	bool checkEdge_i(vector<int> edge_i) {

		//����Ƿ����ظ�������

		for (int j = 0; j < edge_i.size() / 2; j++) {
			int b1 = edge_i[2 * j];
			int b2 = edge_i[2 * j + 1];
			for (int k = j + 1; k < edge_i.size() / 2; k++) {
				int b1_k = edge_i[2 * k];
				int b2_k = edge_i[2 * k + 1];
				if ((b1 == b1_k && b2 == b2_k) || (b1 == b2_k && b2 == b1_k)) {
					return true;
				}
			}
		}
		return false;

	}
	
	bool checkVector(int b1, vector<int> bv) {

		for (int i = 0; i < bv.size(); i++) {
			if (bv[i] == b1) {
				return true;			
			}		
		}
		return false;
	
	}
	//MLS Mapping
	Point3f MLS_pointUpdate(Point3f point_i) {

		int iter_MLS_temp = iter_MLS;
		float h = l_global;

#pragma region Achieve Neibor
		//Achieve Neibor	
		
		std::vector<int> pointNeior = kd.KDTreeSearching_NeighborIndex(point_i);		

		//vector<int> pointNeior = br.pointNeibor[i];
		vector<Point3f> pointNormal_i(pointNeior.size());
		
		for (int i = 0; i < pointNeior.size(); i++) {			
			pointNormal_i[i] = normalVectorGlobal[pointNeior[i]];
		}

#pragma endregion

#pragma region MLS error
		//++++++++++++++++++++interater start+++++++++++++++++++++++++++
		float errorExist = 0.0001;
		Point3f px;
		px = point_i;
		Point3f px_store;
		Point3f nx_store;
		Point3f ax;//new point position
		ax[0] = 0;
		ax[1] = 0;
		ax[2] = 0;
		Point3f nx;//new point normal
		nx[0] = 0;
		nx[1] = 0;
		nx[2] = 0;
		float errorEndTem;//record new 
		float errorStore = 9999;
		float weight;

		while (iter_MLS_temp) {
			
			float fenmu = 0;
			for (int j = 0; j < pointNeior.size(); j++) {

				int indexTemp = pointNeior[j];
				float dis_i = Point2length(pointOriginal[indexTemp], px);
				if (dis_i == 0) {
					continue;
				}
				double eData = -((dis_i / h) * (dis_i / h));
				eData = exp(eData);
				ax[0] = ax[0] + pointOriginal[pointNeior[j]][0] * eData;
				ax[1] = ax[1] + pointOriginal[pointNeior[j]][1] * eData;
				ax[2] = ax[2] + pointOriginal[pointNeior[j]][2] * eData;
				nx[0] = nx[0] + pointNormal_i[j][0] * eData;
				nx[1] = nx[1] + pointNormal_i[j][1] * eData;
				nx[2] = nx[2] + pointNormal_i[j][2] * eData;
				fenmu = fenmu + eData;
			}
			if (fenmu != 0) {
				ax[0] = ax[0] / fenmu;
				ax[1] = ax[1] / fenmu;
				ax[2] = ax[2] / fenmu;
				nx[0] = nx[0] / fenmu;
				nx[1] = nx[1] / fenmu;
				nx[2] = nx[2] / fenmu;
			}
			fenmu = 0;

			//5.3 Set x' = x - n(x')T(a(x')-x)n(x'), weight = n(x')T(a(x')-x)
			weight = nx[0] * (point_i[0] - ax[0]) +
				nx[1] * (point_i[1] - ax[1]) + nx[2] * (point_i[2] - ax[2]);
			px_store[0] = px[0];
			px_store[1] = px[1];
			px_store[2] = px[2];
			nx_store[0] = nx[0];
			nx_store[1] = nx[1];
			nx_store[2] = nx[2];
			px[0] = point_i[0] - weight * nx[0];
			px[1] = point_i[1] - weight * nx[1];
			px[2] = point_i[2] - weight * nx[2];
			//5.4 ||n(x')T(a(x')-x)n(x')||>errorEndTem
			ax[0] = 0;
			ax[1] = 0;
			ax[2] = 0;
			nx[0] = 0;
			nx[1] = 0;
			nx[2] = 0;

			//vector<double> axnew = simMeasurement_cop_a(px, pointNeiborRegualrNum);
			//vector<double> nxnew = simMeasurement_cop_n(px, pointNeiborRegualrNum, pointNeiborNormalRegualrNum);

			for (int j = 0; j < pointNeior.size(); j++) {
				float dis_i = Point2length(pointOriginal[pointNeior[j]], px);
				if (dis_i == 0) {
					continue;
				}
				double eData = -((dis_i / h) * (dis_i / h));
				eData = exp(eData);
				ax[0] = ax[0] + pointOriginal[pointNeior[j]][0] * eData;
				ax[1] = ax[1] + pointOriginal[pointNeior[j]][1] * eData;
				ax[2] = ax[2] + pointOriginal[pointNeior[j]][2] * eData;
				nx[0] = nx[0] + pointNormal_i[j][0] * eData;
				nx[1] = nx[1] + pointNormal_i[j][1] * eData;
				nx[2] = nx[2] + pointNormal_i[j][2] * eData;
				fenmu = fenmu + eData;
			}
			if (fenmu != 0) {
				ax[0] = ax[0] / fenmu;
				ax[1] = ax[1] / fenmu;
				ax[2] = ax[2] / fenmu;
				nx[0] = nx[0] / fenmu;
				nx[1] = nx[1] / fenmu;
				nx[2] = nx[2] / fenmu;
			}

			weight = nx[0] * (point_i[0] - ax[0]) +
				nx[1] * (point_i[1] - ax[1]) + nx[2] * (point_i[2] - ax[2]);

			ax[0] = 0;
			ax[1] = 0;
			ax[2] = 0;
			nx[0] = 0;
			nx[1] = 0;
			nx[2] = 0;

			errorEndTem = abs(weight);
			if (errorEndTem < errorStore) {
				errorStore = errorEndTem;
			}
			else {
				px[0] = px_store[0];
				px[1] = px_store[1];
				px[2] = px_store[2];
				nx[0] = nx_store[0];
				nx[1] = nx_store[1];
				nx[2] = nx_store[2];
				break;
			}
			if (errorEndTem < errorExist) {//|| errorEndTem > errorstore
				break;
			}
			iter_MLS_temp--;
		}
#pragma endregion 
		
		return px;

	}

	vector<Point3f> MLS_pointUpdate_Normal(Point3f point_i) {

		int iter_MLS_temp = iter_MLS;
		float h = l_global;

#pragma region Achieve Neibor
		//Achieve Neibor	

		std::vector<int> pointNeior = kd.KDTreeSearching_NeighborIndex(point_i);

		//vector<int> pointNeior = br.pointNeibor[i];
		vector<Point3f> pointNormal_i(pointNeior.size());

		for (int i = 0; i < pointNeior.size(); i++) {
			pointNormal_i[i] = normalVectorGlobal[pointNeior[i]];
		}

#pragma endregion

#pragma region MLS error
		//++++++++++++++++++++interater start+++++++++++++++++++++++++++
		float errorExist = 0.0001;
		Point3f px;
		px = point_i;
		Point3f px_store;
		Point3f nx_store;
		Point3f ax;//new point position
		ax[0] = 0;
		ax[1] = 0;
		ax[2] = 0;
		Point3f nx;//new point normal
		nx[0] = 0;
		nx[1] = 0;
		nx[2] = 0;
		float errorEndTem;//record new 
		float errorStore = 9999;
		float weight;

		while (iter_MLS_temp) {

			float fenmu = 0;
			for (int j = 0; j < pointNeior.size(); j++) {

				int indexTemp = pointNeior[j];
				float dis_i = Point2length(pointOriginal[indexTemp], px);
				if (dis_i == 0) {
					continue;
				}
				double eData = -((dis_i / h) * (dis_i / h));
				eData = exp(eData);
				ax[0] = ax[0] + pointOriginal[pointNeior[j]][0] * eData;
				ax[1] = ax[1] + pointOriginal[pointNeior[j]][1] * eData;
				ax[2] = ax[2] + pointOriginal[pointNeior[j]][2] * eData;
				nx[0] = nx[0] + pointNormal_i[j][0] * eData;
				nx[1] = nx[1] + pointNormal_i[j][1] * eData;
				nx[2] = nx[2] + pointNormal_i[j][2] * eData;
				fenmu = fenmu + eData;
			}
			if (fenmu != 0) {
				ax[0] = ax[0] / fenmu;
				ax[1] = ax[1] / fenmu;
				ax[2] = ax[2] / fenmu;
				nx[0] = nx[0] / fenmu;
				nx[1] = nx[1] / fenmu;
				nx[2] = nx[2] / fenmu;
			}
			fenmu = 0;

			//5.3 Set x' = x - n(x')T(a(x')-x)n(x'), weight = n(x')T(a(x')-x)
			weight = nx[0] * (point_i[0] - ax[0]) +
				nx[1] * (point_i[1] - ax[1]) + nx[2] * (point_i[2] - ax[2]);
			px_store[0] = px[0];
			px_store[1] = px[1];
			px_store[2] = px[2];
			nx_store[0] = nx[0];
			nx_store[1] = nx[1];
			nx_store[2] = nx[2];
			px[0] = point_i[0] - weight * nx[0];
			px[1] = point_i[1] - weight * nx[1];
			px[2] = point_i[2] - weight * nx[2];
			//5.4 ||n(x')T(a(x')-x)n(x')||>errorEndTem
			ax[0] = 0;
			ax[1] = 0;
			ax[2] = 0;
			nx[0] = 0;
			nx[1] = 0;
			nx[2] = 0;

			//vector<double> axnew = simMeasurement_cop_a(px, pointNeiborRegualrNum);
			//vector<double> nxnew = simMeasurement_cop_n(px, pointNeiborRegualrNum, pointNeiborNormalRegualrNum);

			for (int j = 0; j < pointNeior.size(); j++) {
				float dis_i = Point2length(pointOriginal[pointNeior[j]], px);
				if (dis_i == 0) {
					continue;
				}
				double eData = -((dis_i / h) * (dis_i / h));
				eData = exp(eData);
				ax[0] = ax[0] + pointOriginal[pointNeior[j]][0] * eData;
				ax[1] = ax[1] + pointOriginal[pointNeior[j]][1] * eData;
				ax[2] = ax[2] + pointOriginal[pointNeior[j]][2] * eData;
				nx[0] = nx[0] + pointNormal_i[j][0] * eData;
				nx[1] = nx[1] + pointNormal_i[j][1] * eData;
				nx[2] = nx[2] + pointNormal_i[j][2] * eData;
				fenmu = fenmu + eData;
			}
			if (fenmu != 0) {
				ax[0] = ax[0] / fenmu;
				ax[1] = ax[1] / fenmu;
				ax[2] = ax[2] / fenmu;
				nx[0] = nx[0] / fenmu;
				nx[1] = nx[1] / fenmu;
				nx[2] = nx[2] / fenmu;
			}

			weight = nx[0] * (point_i[0] - ax[0]) +
				nx[1] * (point_i[1] - ax[1]) + nx[2] * (point_i[2] - ax[2]);

			ax[0] = 0;
			ax[1] = 0;
			ax[2] = 0;
			nx[0] = 0;
			nx[1] = 0;
			nx[2] = 0;

			errorEndTem = abs(weight);
			if (errorEndTem < errorStore) {
				errorStore = errorEndTem;
			}
			else {
				px[0] = px_store[0];
				px[1] = px_store[1];
				px[2] = px_store[2];
				nx[0] = nx_store[0];
				nx[1] = nx_store[1];
				nx[2] = nx_store[2];
				break;
			}
			if (errorEndTem < errorExist) {//|| errorEndTem > errorstore
				break;
			}
			iter_MLS_temp--;
		}
#pragma endregion 

		vector<Point3f> finalResult;
		finalResult.push_back(px);
		finalResult.push_back(nx);
		return finalResult;

	}

};

