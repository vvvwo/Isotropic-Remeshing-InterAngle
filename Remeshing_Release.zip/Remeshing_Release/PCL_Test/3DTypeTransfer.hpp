#pragma once
#include <stdio.h>
#include <stdlib.h>
#include <iostream>
#include <fstream>
#include "FileProcess/CBrowseDir.h"
#include "FileProcess/CStatDir.hpp"

class D3DType {

public:
	void XYZtoPLY(string fatherPath) {

		string fileStyle = "*.xyz";
		char filePath[256];
		strcpy_s(filePath, fatherPath.c_str());
		CStatDir statdir;

		if (!statdir.SetInitDir(filePath))
		{
			cout << "error! file path wrong!" << endl;
		}

		statdir.BeginBrowse(fileStyle.c_str());
		printf("OutPut:%d\nOutPutSecond:%d\n", statdir.GetFileCount(), statdir.GetSubdirCount());
		printf("CountNumber:%d\n", statdir.lifp.size());

		//char* fileName = "D:/Project/WindPoly/TestModel/Fig4ePoint.ply";
		//string fileName_Ply(fileName);
		//int index = fileName_Ply.find_last_not_of(".");
		//string fileNameStore_Ply = fileName_Ply.substr(0, index)+"_RO.ply";	

		vector<string> fileNameList = statdir.lifp;

		for (int i = 0; i < fileNameList.size(); i++) {

            vector<Point3f> pointOriginal;

			string pfileString = fileNameList[i];
			int findIndex = pfileString.find(".XYZ");
			string pfileName = pfileString.substr(fatherPath.size(), findIndex - fatherPath.size());
			string pfileStringGenerate = fatherPath + pfileName + ".ply";

			fstream out2;
			out2.open(fileNameList[i], ios::in);
			int SumNum = 0;
			out2 >> SumNum;
			for (int i = 0; i < SumNum; i++) {
				Point3f pi;
				out2 >> pi[0] >> pi[1] >> pi[2];	
				pointOriginal.push_back(pi);
			}
			out2.close();
			SavePLY_Point(pointOriginal, pfileStringGenerate);
		
		}

	}

private:

	void SavePLY_Point(vector<Point3f> points, string fileNameStore) {

		ofstream f1(fileNameStore);

		//f1 << points.size() << " " << facet.size() << " " << 0 << endl;
		f1 << "ply" << endl;
		f1 << "format ascii 1.0" << endl;
		f1 << "comment VCGLIB generated" << endl;
		f1 << "element vertex " << points.size() << endl;
		f1 << "property float x" << endl;
		f1 << "property float y" << endl;
		f1 << "property float z" << endl;
		f1 << "element face 0" << endl;
		f1 << "property list uchar int vertex_indices" << endl;
		f1 << "end_header" << endl;

		for (int i = 0; i < points.size(); i++) {
			f1 << points[i][0] << " " << points[i][1] << " " << points[i][2] << " " << endl;
		}

		f1.close();

	}
};


