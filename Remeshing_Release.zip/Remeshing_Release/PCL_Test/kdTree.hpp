/*********************************************************************************

					  KDTree for Point Searching

						Updating in 2025/05/27

						   By Dr. Chenlei Lv

			The functions includes:
			1. Searching point based on KD-Tree

*********************************************************************************/

#pragma once
#include <iostream> 
#include <pcl/io/pcd_io.h>
#include <pcl/common/impl/io.hpp>
#include <pcl/point_types.h> 
#include <pcl/point_cloud.h>
#include <boost/random.hpp>
#include <pcl/console/time.h>
//#include <pcl/filters/convolution_3d.h>
#include <pcl/filters/fast_bilateral.h>
#include <pcl/filters/bilateral.h>
#include <pcl/kdtree/kdtree_flann.h>
#include "PcLoad.hpp"

using namespace std;

class KDTreeSearching {

public:

	vector<Point3f> pointSet;	
	int k_n = 8;

private:

	pcl::KdTreeFLANN<pcl::PointXYZ> kdtree;
	float averageNeighbor;

public:

	void KDTreeSearching_init(vector<Point3f> point_input) {


		pointSet = point_input;		
		Kd_Tree();

	}

	vector<int> KDTreeSearching_NeighborIndex(Point3f point_i) {

		std::vector<int> pointIdxNKNSearch(k_n);
		std::vector<float> pointNKNSquaredDistance(k_n);
		std::vector<int> result;
		double r_i = pointNKNSquaredDistance[pointNKNSquaredDistance.size() - 1];
		pcl::PointXYZ searchPoint;
		searchPoint.x = point_i[0];
		searchPoint.y = point_i[1];
		searchPoint.z = point_i[2];
		kdtree.nearestKSearch(searchPoint, k_n, pointIdxNKNSearch, pointNKNSquaredDistance);

		return pointIdxNKNSearch;		

	}
		
private:	

	void Kd_Tree() {

		std::cout << "Init kdtree" << std::endl;
		pcl::PointCloud<pcl::PointXYZ>::Ptr cloud(new pcl::PointCloud<pcl::PointXYZ>);
		cloud->width = pointSet.size();
		cloud->height = 1;
		cloud->points.resize(cloud->width * cloud->height);
		// fills a PointCloud with random data
		for (int i = 0; i < pointSet.size(); i++)
		{
			pcl::PointXYZ pxyz;
			cloud->points[i].x = pointSet[i][0];
			cloud->points[i].y = pointSet[i][1];
			cloud->points[i].z = pointSet[i][2];

		}
		kdtree.setInputCloud(cloud);

	}

	

};