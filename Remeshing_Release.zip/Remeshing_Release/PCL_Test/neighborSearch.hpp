﻿/*********************************************************************************

					 Main for Point Cloud Denoising

						Updating in 2022/07/12

						   By Dr. Chenlei Lv

			The functions includes:
			1. Searching point neighbor 

*********************************************************************************/

#pragma once
#include <iostream> 
#include <pcl/io/pcd_io.h>
#include <pcl/common/impl/io.hpp>
#include <pcl/point_types.h> 
#include <pcl/point_cloud.h>
#include <boost/random.hpp>
#include <pcl/console/time.h>
#include <pcl/filters/convolution_3d.h>
#include <pcl/filters/fast_bilateral.h>
#include <pcl/filters/bilateral.h>
#include <pcl/kdtree/kdtree_flann.h>
#include "PcLoad.hpp"

using namespace std;

class NeighborSearch {

public:
	
	vector<Point3f> pointSet;
	vector<float> pointSet_Dis;
	vector<vector<int>> pointNeighbor;
	vector<vector<int>> pointNeighbor_intrinsic;
	int k_n = 9;

private:

	pcl::KdTreeFLANN<pcl::PointXYZ> kdtree;
	float averageNeighbor;

public:

	void NeighborSearch_init(vector<Point3f> point_input) {

		
		pointSet = point_input;	
		pointNeighbor.resize(pointSet.size());
		pointNeighbor_intrinsic.resize(pointSet.size());
		pointSet_Dis.resize(pointSet.size());
		NeighborSearch_Kd_Tree();
	
	}

	void NeighborSearch_Start() {

		averageNeighbor = 0;

		for (int i = 0; i < pointSet.size(); i++) {

			std::vector<int> pointIdxNKNSearch(k_n);
			std::vector<float> pointNKNSquaredDistance(k_n);
			std::vector<int> result;
			double r_i = pointNKNSquaredDistance[pointNKNSquaredDistance.size() - 1];
			pcl::PointXYZ searchPoint;
			searchPoint.x = pointSet[i][0];
			searchPoint.y = pointSet[i][1];
			searchPoint.z = pointSet[i][2];
			kdtree.nearestKSearch(searchPoint, k_n, pointIdxNKNSearch, pointNKNSquaredDistance);			
			pointNeighbor[i].assign(pointIdxNKNSearch.begin() + 1, pointIdxNKNSearch.end());
			averageNeighbor = averageNeighbor + sqrt(pointNKNSquaredDistance[k_n - 1]);
			pointSet_Dis[i] = sqrt(pointNKNSquaredDistance[3]);
		
		}

		averageNeighbor = averageNeighbor / pointSet.size();

		//judge the point neighbor
		for (int i = 0; i < pointNeighbor.size(); i++) {
			vector<int> pointNeighbor_i;
			for (int j = 0; j < pointNeighbor[i].size(); j++) {
				int index_j = pointNeighbor[i][j];
				bool judge_ij = NeighborSearch_NeighborJudge(i, index_j);
				if (judge_ij) {
					pointNeighbor_i.push_back(index_j);				
				}
			}
			pointNeighbor_intrinsic[i] = pointNeighbor_i;
		}

		cout << "pointNeighbor searching finished!" << endl;
	
	}

	void NeighborSearch_labelOutlier(string fileNamePath) {

		vector<bool> pointSet_OutlierJudge = NeighborSearch_OutlierJudge();

		ofstream f1(fileNamePath);
		f1 << "ply" << endl;
		f1 << "format ascii 1.0" << endl;
		f1 << "comment VCGLIB generated" << endl;
		f1 << "element vertex " << pointSet.size() << endl;
		f1 << "property float x" << endl;
		f1 << "property float y" << endl;
		f1 << "property float z" << endl;
		f1 << "property uchar red " << endl;
		f1 << "property uchar green" << endl;
		f1 << "property uchar blue" << endl;
		f1 << "element face 0" << endl;
		f1 << "property list uchar int vertex_indices" << endl;
		f1 << "end_header" << endl;

		for (int i = 0; i < pointSet.size(); i++) {

			if (pointSet_OutlierJudge[i]) {
				f1 << pointSet[i][0] << " " << pointSet[i][1] << " " << pointSet[i][2] << " " <<
					255 << " " << 0 << " " << 0 << endl;							
			}
			else{
				f1 << pointSet[i][0] << " " << pointSet[i][1] << " " << pointSet[i][2] << " " <<
					0 << " " << 0 << " " << 255 << endl;			
			}			

		}

		f1.close();
	
	}

	void NeighborSearch_RemoveOutlier_Save(string fileNamePath) {

		vector<bool> pointSet_OutlierJudge = NeighborSearch_OutlierJudge();

		int point_Num = 0;

		for (int i = 0; i < pointSet_OutlierJudge.size(); i++) {

			if (!pointSet_OutlierJudge[i]) {

				point_Num++;
			
			}
					
		}

		ofstream f1(fileNamePath);
		f1 << "ply" << endl;
		f1 << "format ascii 1.0" << endl;
		f1 << "comment VCGLIB generated" << endl;
		f1 << "element vertex " << point_Num << endl;
		f1 << "property float x" << endl;
		f1 << "property float y" << endl;
		f1 << "property float z" << endl;
		f1 << "property uchar red " << endl;
		f1 << "property uchar green" << endl;
		f1 << "property uchar blue" << endl;
		f1 << "element face 0" << endl;
		f1 << "property list uchar int vertex_indices" << endl;
		f1 << "end_header" << endl;

		for (int i = 0; i < pointSet.size(); i++) {

			if (!pointSet_OutlierJudge[i]) {

				f1 << pointSet[i][0] << " " << pointSet[i][1] << " " << pointSet[i][2] << " " <<
					0 << " " << 0 << " " << 255 << endl;
			
			}		

		}

		f1.close();

	}

	void NeighborSearch_RemoveOutlier_Both_Save(string fileNamePath1, string fileNamePath2) {

		vector<bool> pointSet_OutlierJudge = NeighborSearch_OutlierJudge();

		int point_Num = 0;

		for (int i = 0; i < pointSet_OutlierJudge.size(); i++) {

			if (!pointSet_OutlierJudge[i]) {

				point_Num++;

			}

		}

		ofstream f1(fileNamePath1);
		f1 << "ply" << endl;
		f1 << "format ascii 1.0" << endl;
		f1 << "comment VCGLIB generated" << endl;
		f1 << "element vertex " << point_Num << endl;
		f1 << "property float x" << endl;
		f1 << "property float y" << endl;
		f1 << "property float z" << endl;
		f1 << "property uchar red " << endl;
		f1 << "property uchar green" << endl;
		f1 << "property uchar blue" << endl;
		f1 << "element face 0" << endl;
		f1 << "property list uchar int vertex_indices" << endl;
		f1 << "end_header" << endl;

		for (int i = 0; i < pointSet.size(); i++) {

			if (!pointSet_OutlierJudge[i]) {

				f1 << pointSet[i][0] << " " << pointSet[i][1] << " " << pointSet[i][2] << " " <<
					0 << " " << 0 << " " << 255 << endl;

			}

		}

		f1.close();

		ofstream f2(fileNamePath2);
		f2 << "ply" << endl;
		f2 << "format ascii 1.0" << endl;
		f2 << "comment VCGLIB generated" << endl;
		f2 << "element vertex " << pointSet.size() << endl;
		f2 << "property float x" << endl;
		f2 << "property float y" << endl;
		f2 << "property float z" << endl;
		f2 << "property uchar red " << endl;
		f2 << "property uchar green" << endl;
		f2 << "property uchar blue" << endl;
		f2 << "element face 0" << endl;
		f2 << "property list uchar int vertex_indices" << endl;
		f2 << "end_header" << endl;

		for (int i = 0; i < pointSet.size(); i++) {

			f2 << pointSet[i][0] << " " << pointSet[i][1] << " " << pointSet[i][2] << " " <<
				0 << " " << 0 << " " << 255 << endl;

		}

		f2.close();

	}

	vector<Point3f> NeighborSearch_RemoveOutlier_Return() {

		vector<bool> pointSet_OutlierJudge = NeighborSearch_OutlierJudge();

		int point_Num = 0;

		for (int i = 0; i < pointSet_OutlierJudge.size(); i++) {

			if (!pointSet_OutlierJudge[i]) {

				point_Num++;

			}

		}

		vector<Point3f> pointSetClear;

		for (int i = 0; i < pointSet.size(); i++) {

			if (!pointSet_OutlierJudge[i]) {

				pointSetClear.push_back(pointSet[i]);				

			}

		}

		return pointSetClear;

		

	}

private:	

	vector<bool> NeighborSearch_OutlierJudge() {

		vector<bool> pointSet_OutlierJudge(pointSet.size(), false);
		for (int i = 0; i < pointNeighbor_intrinsic.size(); i++) {
			if (pointNeighbor_intrinsic[i].size() < 4 || pointSet_Dis[i] > averageNeighbor) {
				pointSet_OutlierJudge[i] = true;
			}
		}

		for (int i = 0; i < pointNeighbor_intrinsic.size(); i++) {

			if (pointSet_OutlierJudge[i]) {
				continue;			
			}
			else {
				for (int j = 0; j < pointNeighbor_intrinsic[i].size(); j++) {
					int index_ij = pointNeighbor_intrinsic[i][j];
					if (pointSet_OutlierJudge[index_ij] && pointNeighbor_intrinsic[i].size() < 5) {
						pointSet_OutlierJudge[i] = true;
						break;
					}				
				}			
			}
		
		
		}

		return pointSet_OutlierJudge;	
	
	}

	bool NeighborSearch_NeighborJudge(int a1, int a2) {
		
		//Judge the beighbor point. There have two rules:
		//First, the neighbor relationship should be symmetry, b \in n(a), then a \in n(b)
		//Second, there should have common point for a pair of points, if b \in n(a), then exist a point c, c \in n(a) ∩ n(b)

		bool judge_1 = false;
		bool judge_2 = false;

		//first rule
		vector<int> a2_n = pointNeighbor[a2];
		for (int i = 0; i < a2_n.size(); i++) {
			if (a2_n[i] == a1) {
				judge_1 = true;
				break;			
			}		
		}

		if (!judge_1) {
			return false;		
		}

		//second rule
		vector<int> a1_n = pointNeighbor[a1];
		for (int i = 0; i < a1_n.size(); i++) {
			int a1_ni = a1_n[i];
			if (a1_ni == a2) {
				continue;			
			}
			else {
				int index_i = NeighborSearch_VectorSearching(a1_ni, a2_n);
				if (index_i >= 0) {
					return true;				
				}			
			}			
		}

		return false;
	
	}

	void NeighborSearch_Kd_Tree() {

		std::cout << "Init kdtree" << std::endl;
		pcl::PointCloud<pcl::PointXYZ>::Ptr cloud(new pcl::PointCloud<pcl::PointXYZ>);
		cloud->width = pointSet.size();
		cloud->height = 1;
		cloud->points.resize(cloud->width * cloud->height);
		// fills a PointCloud with random data
		for (int i = 0; i < pointSet.size(); i++)
		{
			pcl::PointXYZ pxyz;
			cloud->points[i].x = pointSet[i][0];
			cloud->points[i].y = pointSet[i][1];
			cloud->points[i].z = pointSet[i][2];

		}
		kdtree.setInputCloud(cloud);
	
	}

	int NeighborSearch_VectorSearching(int a, vector<int> b) {

		for (int i = 0; i < b.size(); i++) {

			if (b[i] == a) {

				return i;
			
			}
		
		}

		return -1;
	
	}

};