/*********************************************************************************

						Measure remeshing quality

						 Updating in 2025/05/29

						   By Dr. Chenlei Lv

			The functions includes:
			1. Provide a mesurement for remeshing result;

*********************************************************************************/
#pragma once
#include <pcl/kdtree/kdtree_flann.h>
using namespace std;

class MeshCheck {

public:

	int count_nonm_g;
	int count_sinP_g;
	float H_d_g;
	float err_g;
		 

private:

	float regularL;
	vector<Point3f> point;
	vector<vector<int>> edge;
	vector<vector<int>> n_1ring;
	vector<Point3f> pointNew;	
	vector<vector<int>> faceNew;	

public:

	void MeshCheck_init(vector<Point3f> pO, vector<Point3f> pN, vector<vector<int>> fN, float l) {

		regularL = l;
		point = pO;
		pointNew = pN;
		faceNew = fN;	
		MeshCheck_EdgeInit();
		Update1Ring();
	
	}

	void MeshCheck_start() {

		count_nonm_g = MeshCheck_ManifoldCheck();
		count_sinP_g = MeshCheck_SinPointCheck();
		H_d_g = MeshCheck_Hd_Check();	
		err_g = MeshCheck_Edge_Check();
	
	}

private:

	void MeshCheck_EdgeInit() {

		//init edge
		if (edge.size() > 0) {
			edge.clear();
		}

		for (int i = 0; i < pointNew.size(); i++) {
			vector<int> edge_i;
			edge.push_back(edge_i);
		}

		//generate neighbor infor for edge
		for (int i = 0; i < faceNew.size(); i++) {

			int b1 = faceNew[i][0];
			int b2 = faceNew[i][1];
			int b3 = faceNew[i][2];

			edge[b1].push_back(b2);
			edge[b1].push_back(b3);

			edge[b2].push_back(b3);
			edge[b2].push_back(b1);

			edge[b3].push_back(b1);
			edge[b3].push_back(b2);

		}		

	}

	//������edge�ṹ�����¼���ÿ�����1������ھӵ�
	void Update1Ring() {

		if (n_1ring.size() > 0) {
			n_1ring.clear();
		}

		for (int i = 0; i < edge.size(); i++) {
			vector<int> n_1ring_i = CheckRepeat(edge[i]);
			n_1ring.push_back(n_1ring_i);
		}

	}
	
	//�ߵ�����һ����
	int MeshCheck_ManifoldCheck() {

		int count_nonm = 0;//��¼�����αߵ�������
		for (int i = 0; i < n_1ring.size(); i++) {
			int b1 = i;	
			for (int j = 0; j < n_1ring[i].size(); j++) {
				int b2 = n_1ring[i][j];
				if (b2 < b1) {
					continue;
				}
				vector<int> b12V = CommonNeighbor(b1, b2);
				if (b12V.size() > 2) {
					count_nonm++;
				}
			}
		}
		cout << "�����αߵ�����Ϊ��" << count_nonm << endl;
		return count_nonm;
	
	}

	vector<int> CommonNeighbor(int b1, int b2) {//help to check common neighbors

		vector<int> b1_neighboir = edge[b1];
		vector<int> common_Vector;

		for (int i = 0; i < b1_neighboir.size() / 2; i++) {

			int b1_1 = b1_neighboir[2 * i];
			int b1_2 = b1_neighboir[2 * i + 1];
			if (b1_1 == b2) {
				common_Vector.push_back(b1_2);
			}
			else if (b1_2 == b2) {
				common_Vector.push_back(b1_1);
			}
			else {
				continue;
			}

		}

		vector<int> cv = CheckRepeat(common_Vector);
		return cv;

	}

	//��һ��vector���ظ�����ɾ��
	vector<int> CheckRepeat(vector<int> edge_temp) {

		vector<int> checkVector;
		for (int i = 0; i < edge_temp.size(); i++) {
			int point_i = edge_temp[i];
			bool judgeR = false;
			for (int j = 0; j < checkVector.size(); j++) {
				if (point_i == checkVector[j]) {
					judgeR = true;
					break;
				}
			}
			if (!judgeR) {
				checkVector.push_back(point_i);
			}
		}
		return checkVector;
	}

	int MeshCheck_SinPointCheck() {//��������

		int count_sinP = 0;
		for (int i = 0; i < n_1ring.size(); i++) {
			if (n_1ring[i].size() <= 1) {
				count_sinP++;			
			}		
		}
		cout << "����������Ϊ��" << count_sinP << endl;
		return count_sinP;
	}

	float MeshCheck_Hd_Check() {//��˹������

		float H_d = -1;

		pcl::KdTreeFLANN<pcl::PointXYZ> kdtree;
		std::cout << "Init kdtree" << std::endl;
		pcl::PointCloud<pcl::PointXYZ>::Ptr cloud(new pcl::PointCloud<pcl::PointXYZ>);
		cloud->width = pointNew.size();
		cloud->height = 1;
		cloud->points.resize(cloud->width * cloud->height);
		// fills a PointCloud with random data
		for (int i = 0; i < pointNew.size(); i++)
		{
			pcl::PointXYZ pxyz;
			cloud->points[i].x = pointNew[i][0];
			cloud->points[i].y = pointNew[i][1];
			cloud->points[i].z = pointNew[i][2];

		}
		kdtree.setInputCloud(cloud);

		for (int i = 0; i < point.size(); i++) {

			std::vector<int> pointIdxNKNSearch(1);
			std::vector<float> pointNKNSquaredDistance(1);			
			pcl::PointXYZ searchPoint;
			searchPoint.x = point[i][0];
			searchPoint.y = point[i][1];
			searchPoint.z = point[i][2];
			kdtree.nearestKSearch(searchPoint, 1, pointIdxNKNSearch, pointNKNSquaredDistance);			
			float dis_i = sqrt(pointNKNSquaredDistance[0]);
			if (dis_i > H_d) {
				H_d = dis_i;			
			}

		}
		cout << "��˹������Ϊ��" << H_d << endl;
		return H_d;

	}

	float MeshCheck_Edge_Check() {//ƽ���߳������

		float err = 0;//��¼�����αߵ�������
		int countEdge = 0;
		for (int i = 0; i < n_1ring.size(); i++) {
			int b1 = i;
			for (int j = 0; j < n_1ring[i].size(); j++) {
				int b2 = n_1ring[i][j];
				if (b2 < b1) {
					continue;
				}
				Point3f p1 = pointNew[b1];
				Point3f p2 = pointNew[b2];		
				float err_ij = Point2length(p1, p2);
				err = err + abs(err_ij - regularL);
				countEdge++;
			}
		}
		err = err / countEdge;
		cout << "ƽ���߳�����⣺" << err << endl;
		return err;
	}

	float Point2length(Point3f p1, Point3f p2) {

		float length_Temp = (p1[0] - p2[0]) * (p1[0] - p2[0]) + (p1[1] - p2[1]) * (p1[1] - p2[1]) + (p1[2] - p2[2]) * (p1[2] - p2[2]);
		length_Temp = sqrt(length_Temp);
		return length_Temp;

	}

};
