/*
#include <iostream>
#include <boost/version.hpp>	//����boostͷ�ļ�
#include <boost/config.hpp>
using namespace std;


int main()
{
	std::cout << "Hello World!\n";

	cout << BOOST_VERSION << endl;
	cout << BOOST_LIB_VERSION << endl;
	cout << BOOST_PLATFORM << endl;
	cout << BOOST_COMPILER << endl;
	cout << BOOST_STDLIB << endl;

	system("pause");
	return 0;

}
*/